define("epi-forms/contentediting/CreateContentViewModel", [// dojo
"dojo/_base/declare", "dojo/_base/lang", "dojo/when", // epi
"epi/shell/TypeDescriptorManager", "epi-cms/contentediting/viewmodel/CreateContentViewModel", "epi-cms/core/ContentReference", // epi-addons
"epi-forms/ModuleSettings"], function ( // dojo
declare, lang, when, // epi
TypeDescriptorManager, CreateContentViewModel, ContentReference, // epi-addons
ModuleSettings) {
  // module:
  //      epi-forms/contentediting/CreateContentViewModel
  // summary:
  //      Overrides CreateContentViewModel class in order to:
  //      - Sets showAllProperties option based on quick layout mode.
  //      - Sets content name based on EPiServer Forms element content type.
  // tags:
  //      public
  return declare([CreateContentViewModel], {
    // =======================================================================
    // Overrided stubs
    // =======================================================================
    _autoPublishSetter: function _autoPublishSetter(
    /*Boolean*/
    autoPublish) {
      // summary:
      //      Sets:
      //      - showAllProperties option based on quick layout mode (ON/OFF) of the EPiServer Forms
      //      - autoPublish option.
      // autoPublish: [Boolean]
      //      The value.
      // tags:
      //      protected, extensions
      this.set("showAllProperties", ModuleSettings.quickLayout ? false : autoPublish);
      this.autoPublish = autoPublish;
    },
    _requestedTypeSetter: function _requestedTypeSetter(
    /*String*/
    requestedType) {
      // summary:
      //      Set requested type.
      //      After the value is set, heading text and content name are also updated.
      // requestedType: [String]
      //      The value.
      // tags:
      //      protected, extensions
      this.inherited(arguments);
      this.defaultName = TypeDescriptorManager.getResourceValue(requestedType, "defaultname");
      this.set("contentName", TypeDescriptorManager.getResourceValue(requestedType, "newitemdefaultname"));
    },
    hasRequiredProperties: function hasRequiredProperties() {
      return this._hasRequiredProperties(this.metadata);
    },
    _saveSuccessHandler: function _saveSuccessHandler(contentLink) {
      // summary:
      // Override Save success handler to return right type of form element
      var ref = new ContentReference(contentLink),
          versionAgnosticRef = ref.createVersionUnspecificReference(),
          changeToNewContext = lang.hitch(this, function (
      /*String*/
      targetLink) {
        this._emitSaveEvent("saveSuccess", {
          newContentLink: targetLink,
          changeContext: true
        });
      });
      when(this.contentDataStore.refresh(contentLink), lang.hitch(this, function (newContent) {
        if (this.addToDestination) {
          this.addToDestination.save({
            contentLink: versionAgnosticRef.toString(),
            name: newContent.name,
            typeIdentifier: newContent.typeIdentifier
          }); // Keep the current context

          this._emitSaveEvent("saveSuccess", {
            changeContext: false
          });
        } else {
          // Change to new context
          changeToNewContext(versionAgnosticRef.toString());
        }
      }));
    }
  });
});
define("epi-forms/contentediting/editors/ValidatorEditor", [// dojo
"dojo/_base/declare", "dojo/_base/lang", "dojo/_base/array", "dojo/topic", "dojo/dom-class", // epi-addons
"epi-forms/contentediting/editors/ChoiceWithEditor", "epi-forms/ModuleSettings"], function ( // dojo
declare, lang, array, topic, domClass, // epi-addons
ChoiceWithEditor, ModuleSettings) {
  // module:
  //      epi-forms/contentediting/editors/ValidatorEditor
  // summary:
  //
  // tags:
  //      protected
  return declare([ChoiceWithEditor], {
    formEditingViewModel: null,
    canEditCustomMessage: false,
    postCreate: function postCreate() {
      // summary:
      //      Listen to event to update validation message (undo/redo operation).
      // tags:
      //      protected
      this.inherited(arguments);
      this.own(topic.subscribe("/epi/forms/validationmessages/update", lang.hitch(this, function (value) {
        var parent = this.domNode.parentElement; // ignore when the editor is in the right of Compare view

        if (domClass.contains(parent, "epi-form-container__section__row__editor--compare")) {
          return;
        }

        this._setValidatorMessages(value);
      })));
    },
    // =======================================================================
    // Protected stubs
    // =======================================================================
    _setCanEditCustomMessageAttr: function _setCanEditCustomMessageAttr(value) {
      // summary:
      //      set disable for custom validator message textbox
      if (value) {
        this.baseClass += " epi-forms-alwaysActiveContainer";
      }

      this.canEditCustomMessage = value;
    },
    _buildItemParams: function _buildItemParams(
    /*Object*/
    item) {
      // summary:
      //      Build item params.
      //      Override to add default validator message for each validator
      // tags:
      //      override
      var itemParams = this.inherited(arguments);
      lang.mixin(itemParams, {
        defaultValidatorMessage: this._getDefaultMessage(itemParams.searchConditions.key),
        formEditingViewModel: this.formEditingViewModel,
        customValidatorMessageReadonly: !this.canEditCustomMessage
      });
      return itemParams;
    },
    _setCheckBoxesValue: function _setCheckBoxesValue(
    /*Array*/
    selectors,
    /*String*/
    value) {
      // summary:
      //      override to set custom validator message
      var customValidatorMessageReadonly = !this.canEditCustomMessage;
      var validators = [];

      if (value) {
        validators = value.split(this._recordSeparator);
      }

      var validatorMessages = []; // When in AllPropertiesCompareView, for each property we will see two panels (left panel and right panel)
      // which help us to compare the property's values in different content's versions. There will be two instances
      // of this ValidatorEditor corresponding to the two panels in Validators property.
      // If this.compareViewModel exists, it means that we are in AllPropertiesCompareView, and the value of the
      // right panel is being set.

      if (this.compareViewModel && this.compareViewModel.rightPropertyMap) {
        validatorMessages = lang.clone(this.compareViewModel.rightPropertyMap.validatorMessages);
        customValidatorMessageReadonly = true; // eslint-disable-next-line brace-style
      } // otherwise, it means that the value of the left panel is being set, or we are in AllPropertiesView. In both
      // cases we can get validatorMessages from formEditingViewModel.
      else {
          validatorMessages = lang.clone(this.formEditingViewModel.getProperty("validatorMessages"));
        }

      array.forEach(selectors, function (widget) {
        var selectorValue = widget.get("selectorValue"),
            validator = array.filter(validators, function (vld) {
          return vld === selectorValue;
        })[0];

        if (!validator) {
          widget.set("selectorChecked", false);
          return; // continue
        }

        widget.set("selectorChecked", true);
        widget.set("customValidatorMessageReadonly", customValidatorMessageReadonly);
        var validatorWithMessage = array.filter(validatorMessages, function (item) {
          return validator.indexOf(item.validator) === 0;
        })[0];
        validatorWithMessage = validatorWithMessage || {
          message: null
        };
        var msg = validatorWithMessage && validatorWithMessage.message ? validatorWithMessage.message.trim() : null;
        widget.set("customValidatorMessageValue", msg);
      }, this);
    },
    _setValidatorMessages: function _setValidatorMessages(validatorMessages) {
      // summary:
      //      Set message for each validator.
      // tags:
      //      private
      var selectors = this.get("itemWidgets");
      array.forEach(selectors, function (widget) {
        var selectorValue = widget.get("selectorValue").split(this._recordFieldSeparator)[0],
            validator = array.filter(validatorMessages, function (msg) {
          return msg.validator === selectorValue;
        })[0];

        if (!validator) {
          return;
        }

        var msg = validator.message ? validator.message.trim() : null;
        widget.set("customValidatorMessageValue", msg);
      }, this);
    },
    _getDefaultMessage: function _getDefaultMessage(selectValidator) {
      // summary:
      //      Get default message for validator.
      // selectValidator: [string]
      //      the validator to get message for
      // tags:
      //      private
      if (!this.allDefaultValidatorMessages || this.allDefaultValidatorMessages.length <= 0) {
        return "";
      }

      selectValidator = selectValidator.toLowerCase();
      var currentDefaultMsg = this.allDefaultValidatorMessages.filter(function (item) {
        return item.key.indexOf(selectValidator) > -1;
      })[0];
      return currentDefaultMsg ? currentDefaultMsg.value : "";
    }
  });
});